# Sportify 运动活动报名平台

## 代码库地址

- 前端仓库：[https://github.com/your-org/sportify-frontend](https://github.com/your-org/sportify-frontend)
- 后端仓库：[https://github.com/your-org/sportify-backend](https://github.com/your-org/sportify-backend)

> 请将 `your-org` 替换为你的实际 Github 用户名或组织名。

---

## 打包平台说明

本项目支持以下平台的打包与部署：

- **Windows**
- **Linux**
- **MacOS**

后端已在 `package.json` 中配置多平台 targets，可通过 [pkg](https://github.com/vercel/pkg) 工具一键打包为独立可执行文件。

---

## 额外实现的功能描述

- **活动本地搜索**：支持在活动列表页面通过关键字实时搜索活动标题。
- **评论与评分**：用户可对已报名活动进行评论和星级评分，支持删除自己的评论。
- **SPA 前端托管**：后端 Express 支持直接托管前端 `dist` 静态资源，实现一体化部署。
- **订单管理**：用户可查看、取消自己的报名订单，管理员可管理所有订单。
- **权限校验**：所有敏感操作均需登录并校验 JWT，支持用户和管理员角色区分。
- **响应式设计**：前端页面适配多端浏览体验。
- **详细错误提示**：前后端均有详细的错误处理和提示，便于用户和开发者排查问题。

---

如需更多说明，请参考主目录下的 `README.md